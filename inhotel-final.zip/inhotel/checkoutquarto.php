<?php session_start();  //PRIMEIRA AÇÃO!!!!! Iniciar a sessão ?> 
<!DOCTYPE html>
<html>
	<head>
		<link 
		href="style/style2.css" 
		title="style" 
		type="text/css" 
		rel="stylesheet"
		media="all"/>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hotel IN</title>
<LINK HREF='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' REL='stylesheet' TYPE='text/css'>
  <LINK HREF ="style/styleHOME.css" REL="stylesheet">
   <LINK HREF ="style/style.css" REL="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>  
  <div class="container">
<NAV>

  <DIV ID="div_logo">
<A HREF="home.php">
<IMG SRC="img/logo.png" ALT="LOGO HOTEL IN" ID="logo">
</A>

<DIV ID="div_opcoes" CLASS="op">

<DIV ID="home">
<A HREF="home.php">
<SPAN >HOME</SPAN>
</A>
</DIV>


<DIV ID="sobre" CLASS="op">
<A HREF="sobre.html">
<SPAN >SOBRE</SPAN>
</A>
</DIV>

<DIV ID="login" CLASS="op">
  <?php 
    if ($_SESSION['status'] == 1){
      echo '<A HREF="php/logoff.php"><SPAN >LOGOFF</SPAN>';
    }else{echo'<A HREF="login.html"><SPAN >LOGIN</SPAN></A>';}
  ?>

</DIV>
<?php 
if ($_SESSION['status']==1){
  if($_SESSION['tipo']==0){
    echo'<DIV ID="sobre" CLASS="op">
<A HREF="php/Loginphp.php">
<SPAN >RESERVAS</SPAN>
</A>
</DIV>';
  }else if($_SESSION['tipo']==1){
    echo'<DIV ID="drop" CLASS="op">
<LI  CLASS="dropdown"> 
              <A HREF="#" CLASS="dropdown-toggle" data-toggle="dropdown" ROLE="button" ARIA-HASPOPUP="true" ARIA-EXPANDED="false"><SPAN>OPERAÇÕES</SPAN><SPAN CLASS="caret"></SPAN></A> 
              <UL CLASS="dropdown-menu">  
                <LI><A HREF="buscareserva.html">Buscar Reserva</A></LI> 
                <LI><A HREF="adicionaponto.html">Adicionar Ponto</A></LI>  
              </UL> 
            </LI> 
</DIV>';
}else if($_SESSION['tipo'] == 2){
  echo'<DIV ID="drop" CLASS="op">
<LI  CLASS="dropdown"> 
              <A HREF="#" CLASS="dropdown-toggle" data-toggle="dropdown" ROLE="button" ARIA-HASPOPUP="true" ARIA-EXPANDED="false"><SPAN>OPERAÇÕES</SPAN><SPAN CLASS="caret"></SPAN></A> 
              <UL CLASS="dropdown-menu"> 
                <LI><A HREF="formulario.php">Cadastrar Hóspede</A></LI> 
                <LI><A HREF="buscahospede.html">Buscar Hóspede</A></LI> 
                <LI><A HREF="buscaquarto.html">Buscar Quarto</A></LI> 
                <LI><A HREF="alterahospede.html">Alterar Hóspede</A></LI> 
                <LI><A HREF="adicionaponto.html">Adicionar ponto</A></LI> 
                <LI><A HREF="buscaponto.html">Busque seus pontos</A></LI> 
              </UL> 
            </LI> 
</DIV>';
}else if($_SESSION['tipo'] == 3){
  echo '<DIV ID="sobre" CLASS="op">
<A HREF="php/loginphp.php">
<SPAN >Painel de Operações</SPAN>
</A>
</DIV>';
}

}else{
echo'<DIV ID="drop" CLASS="op">
<LI  CLASS="dropdown"> 
              <A HREF="#" CLASS="dropdown-toggle" data-toggle="dropdown" ROLE="button" ARIA-HASPOPUP="true" ARIA-EXPANDED="false"><SPAN>INFORMAÇÕES</SPAN><SPAN CLASS="caret"></SPAN></A> 
              <UL CLASS="dropdown-menu"> 
                <LI CLASS="dropdown-header">Apartamento</LI> 
                <LI><A HREF="#">Classic</A></LI>  
                <LI><A HREF="#">Superior</A></LI> 
                <LI><A HREF="#">Luxo</A></LI> 
                <LI><A HREF="#">HipoAlergênico</A></LI> 
                <LI CLASS="dropdown-header">Suíte</LI> 
                <LI><A HREF="#">Classic </A></LI> 
                <LI><A HREF="#">Master </A></LI> 
              </UL> 
            </LI> 
</DIV>';}
?>

</DIV>

</NAV>
	<body>
		
		
		<form method="POST" action="php/checkout.php" enctype="multipart/form-data">
			<fieldset>
				<center>
					<legend>Check-out Quartos</legend>
				</center>	
				
				<br><br>
				
				<label for="nome">Buscar por(campo obrigatório): </label>
				<span><select name="parametro"></span>
					<option selected >Selecione o quarto</option>
					<option >1</option>
					<option >2</option>
					<option >3</option>
					<option >4</option>
					<option >5</option>
					<option >6</option>
					<option >7</option>
					<option >8</option>
					<option >9</option>
					<option >10</option>
					<option >11</option>
					<option >12</option>
					<option >13</option>
					<option >14</option>
					<option >15</option>
					<option >16</option>
					<option >17</option>
					<option >18</option>
					<option >19</option>
					<option >20</option>
					<option >21</option>
					<option >22</option>
					<option >23</option>
					<option >24</option>
					<option >25</option>
					<option >26</option>
					<option >27</option>
					<option >28</option>
					<option >29</option>
					<option >30</option>
					
					
				</select>	
				
				
				<br><br>
				
				<button type="submit">Check-out</button>
						<button><a href="loginphp.php">Voltar</button></a>
				
			</fieldset>
		</form>
		
	</body>
	<FOOTER>
    <SPAN>COPYRIGHT</SPAN>
    <DIV ID="redes_sociais">
        <A HREF="#linkface">
            <IMG SRC="img/Face.png" class="face">
        </A>
        <A HREF="#linkInsta">
            <IMG SRC="img/Inst.png" class="face">
        </A>
        <A HREF="#linkTwitter">
            <IMG SRC="img/Twitter.png" class="face">
        </A>
    
</FOOTER>
</div>
</div>
</div>
</html>