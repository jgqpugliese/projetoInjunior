<?php session_start();  //PRIMEIRA AÇÃO!!!!! Iniciar a sessão ?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hotel IN</title>

<LINK HREF='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' REL='stylesheet' TYPE='text/css'>
  <LINK HREF ="style/styleHOME.css" REL="stylesheet">
   <LINK HREF ="style/style.css" REL="stylesheet">


    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>  
  <div class="container">
<NAV>

  <DIV ID="div_logo">
<A HREF="home.php">
<IMG SRC="img/logo.png" ALT="LOGO HOTEL IN" ID="logo">
</A>

<DIV ID="div_opcoes" CLASS="op">

<DIV ID="home">
<A HREF="home.php">
<SPAN >HOME</SPAN>
</A>
</DIV>


<DIV ID="sobre" CLASS="op">
<A HREF="sobre.html">
<SPAN >SOBRE</SPAN>
</A>
</DIV>

<DIV ID="login" CLASS="op">
  <?php 
    if ($_SESSION['status'] == 1){
      echo '<A HREF="php/logoff.php"><SPAN >LOGOFF</SPAN>';
    }else{echo'<A HREF="login.html"><SPAN >LOGIN</SPAN></A>';}
  ?>

</DIV>
<?php 
if ($_SESSION['status']==1){
  if($_SESSION['tipo']==0){
    echo'<DIV ID="sobre" CLASS="op">
<A HREF="php/Loginphp.php">
<SPAN >RESERVAS</SPAN>
</A>
</DIV>';
  }else if($_SESSION['tipo']==1){
    echo'<DIV ID="drop" CLASS="op">
<LI  CLASS="dropdown"> 
              <A HREF="#" CLASS="dropdown-toggle" data-toggle="dropdown" ROLE="button" ARIA-HASPOPUP="true" ARIA-EXPANDED="false"><SPAN>OPERAÇÕES</SPAN><SPAN CLASS="caret"></SPAN></A> 
              <UL CLASS="dropdown-menu">  
                <LI><A HREF="buscareserva.html">Buscar Reserva</A></LI> 
                <LI><A HREF="adicionaponto.html">Adicionar Ponto</A></LI>  
              </UL> 
            </LI> 
</DIV>';
}else if($_SESSION['tipo'] == 2){
  echo'<DIV ID="drop" CLASS="op">
<LI  CLASS="dropdown"> 
              <A HREF="#" CLASS="dropdown-toggle" data-toggle="dropdown" ROLE="button" ARIA-HASPOPUP="true" ARIA-EXPANDED="false"><SPAN>OPERAÇÕES</SPAN><SPAN CLASS="caret"></SPAN></A> 
              <UL CLASS="dropdown-menu"> 
                <LI><A HREF="formulario.php">Cadastrar Hóspede</A></LI> 
                <LI><A HREF="buscahospede.html">Buscar Hóspede</A></LI> 
                <LI><A HREF="buscaquarto.html">Buscar Quarto</A></LI> 
                <LI><A HREF="alterahospede.html">Alterar Hóspede</A></LI> 
                <LI><A HREF="adicionaponto.html">Adicionar ponto</A></LI> 
                <LI><A HREF="buscaponto.html">Busque seus pontos</A></LI> 
              </UL> 
            </LI> 
</DIV>';
}else if($_SESSION['tipo'] == 3){
  echo '<DIV ID="sobre" CLASS="op">
<A HREF="php/loginphp.php">
<SPAN >Painel de Operações</SPAN>
</A>
</DIV>';
}

}else{
echo'<DIV ID="drop" CLASS="op">
<LI  CLASS="dropdown"> 
              <A HREF="#" CLASS="dropdown-toggle" data-toggle="dropdown" ROLE="button" ARIA-HASPOPUP="true" ARIA-EXPANDED="false"><SPAN>INFORMAÇÕES</SPAN><SPAN CLASS="caret"></SPAN></A> 
              <UL CLASS="dropdown-menu"> 
                <LI CLASS="dropdown-header">Apartamento</LI> 
                <LI><A HREF="#">Classic</A></LI>  
                <LI><A HREF="#">Superior</A></LI> 
                <LI><A HREF="#">Luxo</A></LI> 
                <LI><A HREF="#">HipoAlergênico</A></LI> 
                <LI CLASS="dropdown-header">Suíte</LI> 
                <LI><A HREF="#">Classic </A></LI> 
                <LI><A HREF="#">Master </A></LI> 
              </UL> 
            </LI> 
</DIV>';}
?>

</DIV>

</NAV>
<BODY>

 <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <img class=" first-slide img-responsive" src="img/quartopadrao.jpg" alt="Primeiro slide">
          <div class="container">
            <div class="carousel-caption">
              <h1><span class="titulocarrosel">Exemplo.</h1></span>
              <p><span class="letracarrosel">TAMO JUNTO PRIMEIRO SLIDE</p>     </span>   
            </div>
          </div>
        </div>
        <div class="item">
          <img class=" second-slide img-responsive" src="img/hotel.jpg" alt="Segundo slide">
          <div class="container">
            <div class="carousel-caption">
              <h1><span class="titulocarrosel">Outro exemplo </h1></span>
              <p><span class="letracarrosel">TAMO JUNTO SEGUNDO SLIDE</p></span>
            </div>
          </div>
        </div>
        <div class="item">
          <img class=" third-slide img-responsive" src="img/jantar.jpg" alt="Terceiro slide">
          <div class="container">
            <div class="carousel-caption">
              <h1><span class="titulocarrosel">Ultimo exemplo</h1></span>
              <p><span class="letracarrosel">ACABARAM OS SLIDES</p></span>
            </div>
          </div>
        </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Anterior</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Próximo</span>
      </a>
    </div><!-- /.carousel -->



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
	</div>

	<div class="container">
	<div class="row">
        <div class="col-lg-4">
          <img class="img-responsive" src="img/hotel1.jpg" alt="Generic placeholder image" width="200" height="200">
          <h2>Apartamento Classic</h2>
          <p> Os apartamentos Classic, localizados do 1º ao 3º andar, possuem 26 metros quadrados e estão equipados com duas camas 
(Twin) ou uma cama de casal (King).<br><a href="#"> Saiba Mais </a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img class="img-responsive" src="img/hotel2.jpg" alt="Generic placeholder image" width="200" height="200">
          <h2>Apartamento Superior</h2>
          <p>Os Apartamentos Superiores, localizados do 4º ao 9º andar, proporcionam uma vista ampla dos arredores do hotel, 
com duas camas ou uma cama de casal.<br><a href="#"> Saiba mais </a></p>
        </div><!-- /.col-lg-4 -->
		<div class="col-lg-4">
          <img class="img-responsive" src="img/hotel3.jpg" alt="Generic placeholder image" width="200" height="200">
          <h2>Apartamentos Luxo</h2>
          <p>Os apartamentos Luxo, localizados do 10º ao 13º andar, estão equipados com amenidades especiais e 
		  roupões de banho, com  mobílias que promovem o
		  bem estar, conforto e utilidade. <br><a href="#">Saiba mais </a></p>
        </div><!-- /.col-lg-4 -->
</div>


<FOOTER>
    <SPAN>COPYRIGHT</SPAN>
    <DIV ID="redes_sociais">
        <A HREF="#linkface">
            <IMG SRC="img/Face.png" class="face">
        </A>
        <A HREF="#linkInsta">
            <IMG SRC="img/Inst.png" class="face">
        </A>
        <A HREF="#linkTwitter">
            <IMG SRC="img/Twitter.png" class="face">
        </A>
    
</FOOTER>
</div>
</div>
</div>
</html>