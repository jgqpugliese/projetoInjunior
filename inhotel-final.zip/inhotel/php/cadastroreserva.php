<?php session_start();  //PRIMEIRA AÇÃO!!!!! Iniciar a sessão ?> 
<?php

  
  $data = $_POST['dia_entrada'];
  $d2 = $_POST['dia_saida'];
  $de = date('Y/m/d', strtotime($data));
  echo $de;
  $df = date('Y/m/d', strtotime($d2));
  $email = $_POST['email'];
  $quarto = $_POST['quarto'];
    $link = new mysqli('localhost','root','','hotel');  //abre conexao com banco
      if (!$link) { //testa se a conexão existe
        die('Não foi possível conectar. '); 
      }
      else{
        mysqli_set_charset($link, 'utf8');
         $sql = "select * from usuario where email = '$email';";
        $query = $link->query($sql);
        if($query->num_rows == 0){
                  
                  echo '<span>'.'Email não esta cadastrado'.'</span>'.'</DIV>';
                } 
        else{
          $dados =  $query->fetch_array();
          $id = $dados['id_usuario'];
          $sql = "insert into reserva (id_usuario,id_quarto,data_entrada,data_saida) values ('$id','$quarto','$de','$df')";
          echo $sql;

          $stmt = $link->prepare($sql);
          $ok = $stmt->execute(); 
          if($ok){     
            echo '<div id="formulario">Os dados foram inseridos com sucesso!';
             echo '<a href="javascript:window.history.go(-1)">retorne para a pag anterior</a></div>';
            }
            else{
            echo "<div id='formulario'>Não foi possível realizar a inserção dos dados"
            ."<br><a href=\"formulario.html\">clique aqui para tentar novamente</a></div>";
          }
              }
          }
  ?>