<?php session_start();  //PRIMEIRA AÇÃO!!!!! Iniciar a sessão ?> 

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hotel IN</title>

<LINK HREF='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' REL='stylesheet' TYPE='text/css'>
  <LINK HREF ="../style/styleHOME.css" REL="stylesheet">
   <LINK HREF ="../style/style.css" REL="stylesheet">
    <LINK HREF ="../style/styleCadastro.css" REL="stylesheet">
      <link 
    href="../style/style4.css" 
    title="style" 
    type="text/css" 
    rel="stylesheet"
    media="all"/>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>  
    <?php 
      if ($_SESSION['status'] !== 1 ){
        $email = $_POST['email'];
        $senha =crypt( $_POST['senha'],'queijo');
        $link = new mysqli('localhost','root','','hotel');
      
      if (mysqli_connect_errno()){ //Retorna o código de erro da ultima chamada a função connect
          die('Não foi possível conectar-se ao banco de dados.');
      }
      
      else{


          $sql ="select * from usuario  where email='$email' and senha = '$senha'";

          $query = $link->query($sql);
        if($query->num_rows == 1){
          $dados = $query->fetch_array();
          $id = $dados['id_usuario'];
          $tp = $dados['tipo']; 
          $nome = $dados['nome'];
          
        //Armazenar variaveis na Session
        $_SESSION['id'] = $id;
        $_SESSION['tipo'] = $tp; 
        $_SESSION['nome'] = $nome;
        $_SESSION['status']=1;
        
        
      }
    }
  }
      ?>
  <div class="container">
<NAV>

  <DIV ID="div_logo">
<A HREF="../home.php">
<IMG SRC="../img/logo.png" ALT="LOGO HOTEL IN" ID="logo">
</A>

<DIV ID="div_opcoes" CLASS="op">

<DIV ID="home">
<A HREF="../home.php">
<SPAN >HOME</SPAN>
</A>
</DIV>


<DIV ID="sobre" CLASS="op">
<A HREF="sobre.html">
<SPAN >SOBRE</SPAN>
</A>
</DIV>

<DIV ID="login" CLASS="op">
  <?php 
    if ($_SESSION['status'] == 1){
      echo '<A HREF="logoff.php"><SPAN >LOGOFF</SPAN>';
    }else{echo'<A HREF="login.html"><SPAN >LOGIN</SPAN></A>';}
  ?>

</DIV>
<?php 
if ($_SESSION['status']==1){
  if($_SESSION['tipo']==0){
    echo'<DIV ID="sobre" CLASS="op">
<A HREF="Loginphp.php">
<SPAN >RESERVAS</SPAN>
</A>
</DIV>';
  }else if($_SESSION['tipo']==1){
    echo'<DIV ID="drop" CLASS="op">
<LI  CLASS="dropdown"> 
              <A HREF="#" CLASS="dropdown-toggle" data-toggle="dropdown" ROLE="button" ARIA-HASPOPUP="true" ARIA-EXPANDED="false"><SPAN>OPERAÇÕES</SPAN><SPAN CLASS="caret"></SPAN></A> 
              <UL CLASS="dropdown-menu">  
                <LI><A HREF="../buscareserva.html">Buscar Reserva</A></LI> 
                <LI><A HREF="../addponto.php">Adicionar Ponto</A></LI>
                <LI><A HREF="buscaponto.php">Busque seus pontos</A></LI>  
              </UL> 
            </LI> 
</DIV>';
}else if($_SESSION['tipo'] == 2){
  echo'<DIV ID="drop" CLASS="op">
<LI  CLASS="dropdown"> 
              <A HREF="#" CLASS="dropdown-toggle" data-toggle="dropdown" ROLE="button" ARIA-HASPOPUP="true" ARIA-EXPANDED="false"><SPAN>OPERAÇÕES</SPAN><SPAN CLASS="caret"></SPAN></A> 
              <UL CLASS="dropdown-menu"> 
                <LI><A HREF="../formulario.php">Cadastrar Hóspede</A></LI> 
                <LI><A HREF="../buscahospede.html">Buscar Hóspede</A></LI> 
                <LI><A HREF="../buscaquarto.html">Buscar Quarto</A></LI> 
                <LI><a href="../addreserva.php">Criar Reserva</a></LI> 
                <LI><A HREF="../addponto.php">Adicionar ponto</A></LI> 
                <LI><A HREF="buscaponto.php">Busque seus pontos</A></LI> 
              </UL> 
            </LI> 
</DIV>';
}else if($_SESSION['tipo'] == 3){
  echo '<DIV ID="sobre" CLASS="op">
<A HREF="loginphp.php">
<SPAN >Painel de Operações</SPAN>
</A>
</DIV>';
}

}else{
echo'<DIV ID="drop" CLASS="op">
<LI  CLASS="dropdown"> 
              <A HREF="#" CLASS="dropdown-toggle" data-toggle="dropdown" ROLE="button" ARIA-HASPOPUP="true" ARIA-EXPANDED="false"><SPAN>INFORMAÇÕES</SPAN><SPAN CLASS="caret"></SPAN></A> 
              <UL CLASS="dropdown-menu"> 
                <LI CLASS="dropdown-header">Apartamento</LI> 
                <LI><A HREF="#">Classic</A></LI>  
                <LI><A HREF="#">Superior</A></LI> 
                <LI><A HREF="#">Luxo</A></LI> 
                <LI><A HREF="#">HipoAlergênico</A></LI> 
                <LI CLASS="dropdown-header">Suíte</LI> 
                <LI><A HREF="#">Classic </A></LI> 
                <LI><A HREF="#">Master </A></LI> 
              </UL> 
            </LI> 
</DIV>';}
?>

</DIV>

</NAV>
<BODY>
<?php
    
    if ($_SESSION['status'] === 1){
      if ($_SESSION['tipo'] == 0){
              $link = new mysqli('localhost','root','','hotel');
              
              if (mysqli_connect_errno()){ //Retorna o código de erro da ultima chamada a função connect
                  die('Não foi possível conectar-se ao banco de dados.');
              }
              
              else{
                $ii = $_SESSION['id'];
                $sql = " select distinct reserva.data_entrada ,reserva.data_saida,reserva.id_quarto, tipo_quarto.tipo, reserva.id_reserva from usuario ,reserva join quarto join tipo_quarto where reserva.id_usuario = '$ii' and reserva.id_quarto =  quarto.id_quarto and quarto.id_tipo = tipo_quarto.id_tipo ";
                
                $query = $link->query($sql);
                echo '<DIV ID="formulario">'.'<span>'.'Olá '.$_SESSION['nome'].'</span>';
                echo '<br>';
                if($query->num_rows == 0){
                  
                  echo '<span>'.'Você não possui reservas.'.'</span>'.'</DIV>';
                }
                else{
                  echo 'Registros encontrados: '.$query->num_rows;
                  echo 'Suas reservas :'.'<br><br>';
                  while ($dados = $query->fetch_array()) {
                  
                  echo 'Numero do quarto:'.$dados['id_quarto'].'<br>';
                  echo 'data de entrada:'.$dados['data_entrada'].'<br>';
                  echo 'data de saida:'.$dados['data_saida'].'<br>';
                  echo 'Tipo do quarto:'.$dados['tipo'];
                  echo '<br><br>';
                  }
                  echo '</div>';
                }
              }

                    }





          else if ($_SESSION['tipo'] == 2){
          echo'  <div id="bordeca">';
         
          echo 'Hello '.$_SESSION['nome'].'. <br>';
          
          echo '<div class="separa">'.
           '<button><a href="../formulario.php">Cadastrar Hóspede</button></a>'.
           '<button><a href="../buscahospede.html">Buscar Hóspede</button></a>'.
           '</div>'.
           '<div class="separa2">'.
           '<button><a href="../buscaquarto.html">Buscar Quarto</button></a>'.
           '<button><a href="../addreserva.php">Criar Reserva</button></a>'.
           '</div>'.
           '<div class="separa">'.
           '<button><a href="../addponto.php">Adicionar ponto</button></a>'.
           '<button><a href="buscaponto.php">Busque seus pontos</button></a>'.
           '</div>';
           echo '<div class="separa">
                   <button><a href="../checkinquarto.php">Check-in</button></a>
                  <button><a href="../checkoutquarto.php">Check-out</button></a>
                </div>
                </div>';
          }




           else if ($_SESSION['tipo'] == 1){
            echo 'Olá '.$_SESSION['nome'];
      echo '<div id="bordeca">'.
      '<div class="separa">'.
        '<button><a href="../buscareserva.html">Buscar Reservas</button></a>'.
        '</div>'.
        '<div class="separa">'.
        '<button><a href="../addponto.php">Adicionar ponto</button></a>'.
        '<button><a href="buscaponto.php">Busque seus pontos</button></a>'.
        '</div>'.
        '<div class="separa">'.
        '</div>'.
        '</div>'
        ;
          }
          
          else if($_SESSION['tipo'] == 3){
            if ($_SESSION['nome'] == 'susana viera'){
          echo '<img src="../img/susana_viera.jpg" id="foto_deusa"><br>';
        } 
        echo 'Olá '.$_SESSION['nome'].' ,minha majestade!'.'<br><br>' ;
            echo '<div id="bordeca">
      <div class="separa">
        <button><a href="../formulario.php">Cadastrar Hóspede</button></a>
        <button><a href="../buscahospede.html">Buscar Hóspede</button></a>
        </div>
        <div class="separa2">
        <button><a href="../buscaquarto.html">Buscar Quarto</button></a>
        <button><a href="../alterahospede.html">Alterar Hóspede</button></a>
        </div>
        <div class="separa">
        <button><a href="../addponto.php">Adicionar ponto</button></a>
        <button><a href="buscaponto.php">Meus pontos</button></a>
        <div class="separa">
        
                <button><a href="../formulario2.php">Cadastramento de Funcionários</button></a>
                </div>
                <div class="separa">
                  <button><a href="buscareserva.php">Buscar Reservas</button></a>
                  <button><a href="../addreserva.php">Criar Reserva</button></a>
                </div>
                <div class="separa">
                   <button><a href="../checkinquarto.php">Check-in</button></a>
                  <button><a href="../checkoutquarto.php">Check-out</button></a>
                </div>
        </div>
  
        
        </div>';
          }



    
      }
       
          
        ?>
         
  <FOOTER>
    <SPAN>COPYRIGHT</SPAN>
    <DIV ID="redes_sociais">
        <A HREF="#linkface">
            <IMG SRC="../img/Face.png" class="face">
        </A>
        <A HREF="#linkInsta">
            <IMG SRC="../img/Inst.png" class="face">
        </A>
        <A HREF="#linkTwitter">
            <IMG SRC="../img/Twitter.png" class="face">
        </A>
    
</FOOTER>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
</div>
</div>
</div>
</body>
</html>