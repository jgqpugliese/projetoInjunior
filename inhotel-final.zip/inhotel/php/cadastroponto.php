<?php session_start();  //PRIMEIRA AÇÃO!!!!! Iniciar a sessão ?> 
<?php
  
  $he = $_POST['hora-entrada'];
  $hf = $_POST['hora-saida'];
  $dia = $_POST['dia'];
  $mes = $_POST['mes'];
  $ano = $_POST['ano'];
  $id = $_SESSION['id'];
  $nhf=$hf.':00';
  $nhe = $he.':00';
    $link = new mysqli('localhost','root','','hotel');  //abre conexao com banco
      if (!$link) { //testa se a conexão existe
        die('Não foi possível conectar. '); 
      }
      else{
        mysqli_set_charset($link, 'utf8');
        $sql = "insert into ponto (id_usuario,hora_entrada,hora_saida,dia,id_mes,ano,hora_trabalhada) values ('$id','$nhe','$nhf','$dia','$mes','$ano','2')";
        $stmt = $link->prepare($sql);
      
      #como passar o date.
        
        $ok = $stmt->execute(); 
        
        if($ok){     
            echo '<div id="formulario">Os dados foram inseridos com sucesso!';
             echo '<a href="javascript:window.history.go(-1)">retorne para a pag anterior</a></div>';
            }
            else{
            echo "<div id='formulario'>Não foi possível realizar a inserção dos dados"
            ."<br><a href=\"formulario.html\">clique aqui para tentar novamente</a></div>";
          }
      }
  ?>