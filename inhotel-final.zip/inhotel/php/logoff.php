<?php session_start();  //PRIMEIRA AÇÃO!!!!! Iniciar a sessão ?> 
<?php 
$_SESSION['status']=0;
header('Location: ../login.html');
?>